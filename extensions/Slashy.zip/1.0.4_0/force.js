Node.prototype.removeChild = function(child) {
	child.remove()
}